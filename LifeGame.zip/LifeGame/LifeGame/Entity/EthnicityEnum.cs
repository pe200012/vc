﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LifeGame
{
   public enum EthnicityEnum
   {
      人族,
      兽族
   }
}
